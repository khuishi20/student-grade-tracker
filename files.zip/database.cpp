#include "database.h"
#include <sqlite3.h>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

static sqlite3* db = nullptr;

// --- Helper: compute grade from percentage ---
static string compute_grade(double pct) {
    if (pct >= 90) return "A+";
    if (pct >= 80) return "A";
    if (pct >= 70) return "B";
    if (pct >= 60) return "C";
    if (pct >= 50) return "D";
    return "F";
}

// --- Init ---
bool db_init() {
    int rc = sqlite3_open("grades.db", &db);
    if (rc != SQLITE_OK) {
        cerr << "Cannot open database: " << sqlite3_errmsg(db) << endl;
        return false;
    }

    const char* sql =
        "CREATE TABLE IF NOT EXISTS students ("
        "  id          INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  name        TEXT NOT NULL,"
        "  roll_number TEXT UNIQUE NOT NULL,"
        "  class       TEXT NOT NULL"
        ");"
        "CREATE TABLE IF NOT EXISTS subjects ("
        "  id        INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  name      TEXT UNIQUE NOT NULL,"
        "  max_marks INTEGER NOT NULL"
        ");"
        "CREATE TABLE IF NOT EXISTS marks ("
        "  id         INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  student_id INTEGER NOT NULL,"
        "  subject_id INTEGER NOT NULL,"
        "  marks      INTEGER NOT NULL,"
        "  FOREIGN KEY(student_id) REFERENCES students(id),"
        "  FOREIGN KEY(subject_id) REFERENCES subjects(id),"
        "  UNIQUE(student_id, subject_id)"
        ");";

    char* err = nullptr;
    rc = sqlite3_exec(db, sql, nullptr, nullptr, &err);
    if (rc != SQLITE_OK) {
        cerr << "SQL error: " << err << endl;
        sqlite3_free(err);
        return false;
    }
    return true;
}

void db_close() {
    if (db) sqlite3_close(db);
}

// --- Students ---
bool db_add_student(const string& name, const string& roll, const string& cls) {
    const char* sql = "INSERT INTO students (name, roll_number, class) VALUES (?, ?, ?);";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, roll.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, cls.c_str(),  -1, SQLITE_STATIC);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool db_delete_student(int student_id) {
    // Delete marks first
    const char* sql1 = "DELETE FROM marks WHERE student_id = ?;";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql1, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, student_id);
    sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    // Delete student
    const char* sql2 = "DELETE FROM students WHERE id = ?;";
    sqlite3_prepare_v2(db, sql2, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, student_id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

void db_list_students() {
    const char* sql = "SELECT id, name, roll_number, class FROM students ORDER BY id;";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);

    cout << left << setw(5) << "ID"
         << setw(25) << "Name"
         << setw(15) << "Roll No."
         << setw(15) << "Class" << endl;
    cout << string(60, '-') << endl;

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        cout << left
             << setw(5)  << sqlite3_column_int(stmt, 0)
             << setw(25) << (const char*)sqlite3_column_text(stmt, 1)
             << setw(15) << (const char*)sqlite3_column_text(stmt, 2)
             << setw(15) << (const char*)sqlite3_column_text(stmt, 3)
             << endl;
    }
    sqlite3_finalize(stmt);
}

// --- Subjects ---
bool db_add_subject(const string& name, int max_marks) {
    const char* sql = "INSERT INTO subjects (name, max_marks) VALUES (?, ?);";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_int(stmt, 2, max_marks);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

void db_list_subjects() {
    const char* sql = "SELECT id, name, max_marks FROM subjects ORDER BY id;";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);

    cout << left << setw(5) << "ID"
         << setw(25) << "Subject"
         << setw(15) << "Max Marks" << endl;
    cout << string(45, '-') << endl;

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        cout << left
             << setw(5)  << sqlite3_column_int(stmt, 0)
             << setw(25) << (const char*)sqlite3_column_text(stmt, 1)
             << setw(15) << sqlite3_column_int(stmt, 2)
             << endl;
    }
    sqlite3_finalize(stmt);
}

// --- Marks ---
bool db_enter_marks(int student_id, int subject_id, int marks) {
    // Check max_marks for validation
    const char* chk = "SELECT max_marks FROM subjects WHERE id = ?;";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, chk, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, subject_id);
    if (sqlite3_step(stmt) != SQLITE_ROW) {
        sqlite3_finalize(stmt);
        cout << "Subject not found." << endl;
        return false;
    }
    int max_marks = sqlite3_column_int(stmt, 0);
    sqlite3_finalize(stmt);

    if (marks < 0 || marks > max_marks) {
        cout << "Marks must be between 0 and " << max_marks << "." << endl;
        return false;
    }

    const char* sql = "INSERT OR REPLACE INTO marks (student_id, subject_id, marks) VALUES (?, ?, ?);";
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, student_id);
    sqlite3_bind_int(stmt, 2, subject_id);
    sqlite3_bind_int(stmt, 3, marks);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

// --- Console Report ---
void db_print_student_report(int student_id) {
    StudentData data;
    if (!db_get_student_data(student_id, data)) {
        cout << "Student not found or no marks entered." << endl;
        return;
    }

    cout << "\n========================================" << endl;
    cout << "           STUDENT REPORT CARD          " << endl;
    cout << "========================================" << endl;
    cout << "Name     : " << data.name        << endl;
    cout << "Roll No. : " << data.roll_number << endl;
    cout << "Class    : " << data.cls         << endl;
    cout << "----------------------------------------" << endl;

    cout << left << setw(20) << "Subject"
         << setw(10) << "Marks"
         << setw(10) << "Max"
         << setw(10) << "Pct%"
         << setw(8)  << "Grade" << endl;
    cout << string(58, '-') << endl;

    for (int i = 0; i < data.subject_count; i++) {
        SubjectMark& sm = data.subjects[i];
        cout << left
             << setw(20) << sm.subject_name
             << setw(10) << sm.marks_obtained
             << setw(10) << sm.max_marks
             << setw(10) << fixed << setprecision(1) << sm.percentage
             << setw(8)  << sm.grade << endl;
    }

    cout << string(58, '=') << endl;
    cout << "Overall Percentage : " << fixed << setprecision(2) << data.overall_percentage << "%" << endl;
    cout << "Overall Grade      : " << data.overall_grade << endl;
    cout << "Result             : " << data.status << endl;
    cout << "========================================" << endl;
}

// --- Get student data for export ---
bool db_get_student_data(int student_id, StudentData& data) {
    // Get student info
    const char* sql1 = "SELECT id, name, roll_number, class FROM students WHERE id = ?;";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql1, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, student_id);
    if (sqlite3_step(stmt) != SQLITE_ROW) {
        sqlite3_finalize(stmt);
        return false;
    }
    data.id          = sqlite3_column_int(stmt, 0);
    data.name        = (const char*)sqlite3_column_text(stmt, 1);
    data.roll_number = (const char*)sqlite3_column_text(stmt, 2);
    data.cls         = (const char*)sqlite3_column_text(stmt, 3);
    sqlite3_finalize(stmt);

    // Get marks
    const char* sql2 =
        "SELECT s.name, m.marks, s.max_marks "
        "FROM marks m "
        "JOIN subjects s ON m.subject_id = s.id "
        "WHERE m.student_id = ? ORDER BY s.name;";
    sqlite3_prepare_v2(db, sql2, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, student_id);

    data.subject_count = 0;
    int total_marks = 0, total_max = 0;
    bool failed = false;

    while (sqlite3_step(stmt) == SQLITE_ROW && data.subject_count < 20) {
        SubjectMark& sm = data.subjects[data.subject_count];
        sm.subject_name    = (const char*)sqlite3_column_text(stmt, 0);
        sm.marks_obtained  = sqlite3_column_int(stmt, 1);
        sm.max_marks       = sqlite3_column_int(stmt, 2);
        sm.percentage      = (double)sm.marks_obtained / sm.max_marks * 100.0;
        sm.grade           = compute_grade(sm.percentage);
        if (sm.percentage < 35.0) failed = true;
        total_marks += sm.marks_obtained;
        total_max   += sm.max_marks;
        data.subject_count++;
    }
    sqlite3_finalize(stmt);

    if (data.subject_count == 0) return false;

    data.overall_percentage = (double)total_marks / total_max * 100.0;
    data.overall_grade      = compute_grade(data.overall_percentage);
    data.status             = (failed || data.overall_percentage < 35.0) ? "FAIL" : "PASS";
    return true;
}
