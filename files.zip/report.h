#ifndef REPORT_H
#define REPORT_H

#include <string>
using namespace std;

void export_html_report(int student_id, const string& filename);

#endif
