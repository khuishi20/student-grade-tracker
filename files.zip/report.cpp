#include "report.h"
#include "database.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>

using namespace std;

static string grade_color(const string& grade) {
    if (grade == "A+") return "#2ecc71";
    if (grade == "A")  return "#27ae60";
    if (grade == "B")  return "#3498db";
    if (grade == "C")  return "#f39c12";
    if (grade == "D")  return "#e67e22";
    return "#e74c3c"; // F
}

void export_html_report(int student_id, const string& filename) {
    StudentData data;
    if (!db_get_student_data(student_id, data)) {
        cout << "Student not found or no marks available." << endl;
        return;
    }

    ofstream file(filename);
    if (!file.is_open()) {
        cout << "Could not create file: " << filename << endl;
        return;
    }

    string status_color = (data.status == "PASS") ? "#2ecc71" : "#e74c3c";

    file << R"(<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Report Card - )" << data.name << R"(</title>
  <link rel="stylesheet" href="web/style.css">
</head>
<body>
  <div class="page">
    <header class="school-header">
      <div class="school-logo">🎓</div>
      <div>
        <h1>Student Grade Report</h1>
        <p class="subtitle">Academic Performance Report Card</p>
      </div>
    </header>

    <section class="student-info">
      <div class="info-grid">
        <div class="info-item">
          <span class="label">Student Name</span>
          <span class="value">)" << data.name << R"(</span>
        </div>
        <div class="info-item">
          <span class="label">Roll Number</span>
          <span class="value">)" << data.roll_number << R"(</span>
        </div>
        <div class="info-item">
          <span class="label">Class</span>
          <span class="value">)" << data.cls << R"(</span>
        </div>
        <div class="info-item">
          <span class="label">Overall Result</span>
          <span class="value result-badge" style="background:)" << status_color << R"(">)" << data.status << R"(</span>
        </div>
      </div>
    </section>

    <section class="marks-section">
      <h2>Subject-wise Performance</h2>
      <table class="marks-table">
        <thead>
          <tr>
            <th>Subject</th>
            <th>Marks Obtained</th>
            <th>Maximum Marks</th>
            <th>Percentage</th>
            <th>Grade</th>
          </tr>
        </thead>
        <tbody>
)";

    for (int i = 0; i < data.subject_count; i++) {
        SubjectMark& sm = data.subjects[i];
        ostringstream pct_str;
        pct_str << fixed << setprecision(1) << sm.percentage << "%";
        string gc = grade_color(sm.grade);

        file << "          <tr>\n"
             << "            <td>" << sm.subject_name << "</td>\n"
             << "            <td class='center'>" << sm.marks_obtained << "</td>\n"
             << "            <td class='center'>" << sm.max_marks << "</td>\n"
             << "            <td class='center'>\n"
             << "              <div class='progress-bar'>\n"
             << "                <div class='progress-fill' style='width:" << sm.percentage << "%;background:" << gc << "'></div>\n"
             << "              </div>\n"
             << "              <span class='pct-text'>" << pct_str.str() << "</span>\n"
             << "            </td>\n"
             << "            <td class='center'><span class='grade-badge' style='background:" << gc << "'>" << sm.grade << "</span></td>\n"
             << "          </tr>\n";
    }

    ostringstream overall_str;
    overall_str << fixed << setprecision(2) << data.overall_percentage;

    file << R"(        </tbody>
      </table>
    </section>

    <section class="summary">
      <div class="summary-grid">
        <div class="summary-card">
          <div class="summary-label">Overall Percentage</div>
          <div class="summary-value">)" << overall_str.str() << R"(%</div>
        </div>
        <div class="summary-card">
          <div class="summary-label">Overall Grade</div>
          <div class="summary-value" style="color:)" << grade_color(data.overall_grade) << R"(">)" << data.overall_grade << R"(</div>
        </div>
        <div class="summary-card">
          <div class="summary-label">Subjects Taken</div>
          <div class="summary-value">)" << data.subject_count << R"(</div>
        </div>
      </div>
    </section>

    <section class="grade-legend">
      <h3>Grade Scale</h3>
      <div class="legend-items">
        <span class="legend-item" style="background:#2ecc71">A+ ≥ 90%</span>
        <span class="legend-item" style="background:#27ae60">A ≥ 80%</span>
        <span class="legend-item" style="background:#3498db">B ≥ 70%</span>
        <span class="legend-item" style="background:#f39c12">C ≥ 60%</span>
        <span class="legend-item" style="background:#e67e22">D ≥ 50%</span>
        <span class="legend-item" style="background:#e74c3c">F &lt; 50%</span>
      </div>
    </section>

    <footer>
      <p>Generated by Student Grade Tracker &mdash; <em>github.com/yourusername/student-grade-tracker</em></p>
    </footer>
  </div>
</body>
</html>
)";

    file.close();
}
