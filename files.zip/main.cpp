#include <iostream>
#include <string>
#include <limits>
#include "database.h"
#include "report.h"

using namespace std;

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void printHeader() {
    cout << "========================================" << endl;
    cout << "      STUDENT GRADE TRACKER v1.0        " << endl;
    cout << "========================================" << endl;
}

void printMenu() {
    cout << "\n--- MAIN MENU ---" << endl;
    cout << "1. Add Student" << endl;
    cout << "2. Add Subject" << endl;
    cout << "3. Enter Marks" << endl;
    cout << "4. View All Students" << endl;
    cout << "5. View Student Report" << endl;
    cout << "6. Export HTML Report Card" << endl;
    cout << "7. Delete Student" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter choice: ";
}

int getIntInput(const string& prompt) {
    int val;
    cout << prompt;
    while (!(cin >> val)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. " << prompt;
    }
    cin.ignore();
    return val;
}

string getStringInput(const string& prompt) {
    string val;
    cout << prompt;
    getline(cin, val);
    return val;
}

int main() {
    // Initialize database
    if (!db_init()) {
        cerr << "Error: Could not initialize database!" << endl;
        return 1;
    }

    int choice;
    do {
        clearScreen();
        printHeader();
        printMenu();
        cin >> choice;
        cin.ignore();

        switch (choice) {
            case 1: {
                string name = getStringInput("Enter student name: ");
                string roll = getStringInput("Enter roll number: ");
                string cls  = getStringInput("Enter class: ");
                if (db_add_student(name, roll, cls)) {
                    cout << "\n✓ Student added successfully!" << endl;
                } else {
                    cout << "\n✗ Failed to add student (roll number may already exist)." << endl;
                }
                break;
            }
            case 2: {
                string subject = getStringInput("Enter subject name: ");
                int max_marks  = getIntInput("Enter maximum marks: ");
                if (db_add_subject(subject, max_marks)) {
                    cout << "\n✓ Subject added successfully!" << endl;
                } else {
                    cout << "\n✗ Failed to add subject." << endl;
                }
                break;
            }
            case 3: {
                db_list_students();
                int student_id = getIntInput("Enter student ID: ");
                db_list_subjects();
                int subject_id = getIntInput("Enter subject ID: ");
                int marks      = getIntInput("Enter marks obtained: ");
                if (db_enter_marks(student_id, subject_id, marks)) {
                    cout << "\n✓ Marks entered successfully!" << endl;
                } else {
                    cout << "\n✗ Failed to enter marks." << endl;
                }
                break;
            }
            case 4: {
                cout << "\n--- ALL STUDENTS ---" << endl;
                db_list_students();
                break;
            }
            case 5: {
                db_list_students();
                int student_id = getIntInput("Enter student ID to view report: ");
                db_print_student_report(student_id);
                break;
            }
            case 6: {
                db_list_students();
                int student_id = getIntInput("Enter student ID to export: ");
                string filename = "report_" + to_string(student_id) + ".html";
                export_html_report(student_id, filename);
                cout << "\n✓ Report exported to: " << filename << endl;
                break;
            }
            case 7: {
                db_list_students();
                int student_id = getIntInput("Enter student ID to delete: ");
                string confirm = getStringInput("Are you sure? (yes/no): ");
                if (confirm == "yes") {
                    if (db_delete_student(student_id)) {
                        cout << "\n✓ Student deleted." << endl;
                    } else {
                        cout << "\n✗ Failed to delete student." << endl;
                    }
                } else {
                    cout << "Cancelled." << endl;
                }
                break;
            }
            case 0:
                cout << "\nGoodbye!" << endl;
                break;
            default:
                cout << "\nInvalid choice. Try again." << endl;
        }

        if (choice != 0) {
            cout << "\nPress Enter to continue...";
            cin.get();
        }

    } while (choice != 0);

    db_close();
    return 0;
}
