# 📚 Student Grade Tracker

A command-line student grade management system built with **C++**, **C**, **SQL (SQLite)**, and **CSS**.  
Stores student data in a local database and exports beautiful HTML report cards.

---

## ✨ Features

- ➕ Add / remove students and subjects
- 📝 Enter and update marks per subject
- 📊 Auto-calculate percentages and letter grades
- 📋 View formatted reports in the terminal
- 🌐 Export styled HTML report cards (CSS included)
- 🗄️ Persistent SQLite database — data is saved between runs

---

## 🛠️ Tech Stack

| Technology | Used For |
|---|---|
| C++ | Core application logic, menus |
| C (SQLite API) | Database read/write operations |
| SQL | Student, subject, and marks queries |
| CSS | Styled HTML report card export |
| Git / GitHub | Version control |

---

## 📂 Project Structure

```
student-grade-tracker/
├── src/
│   ├── main.cpp        # Entry point and menu system
│   ├── database.cpp    # SQLite database operations
│   └── report.cpp      # HTML report exporter
├── include/
│   ├── database.h      # Database function declarations
│   └── report.h        # Report function declarations
├── web/
│   └── style.css       # Report card stylesheet
├── Makefile
└── README.md
```

---

## 🚀 Getting Started

### Prerequisites

- `g++` compiler (C++17 or later)
- `sqlite3` library

**Install on Ubuntu/Debian:**
```bash
sudo apt install g++ libsqlite3-dev
```

**Install on macOS (Homebrew):**
```bash
brew install sqlite3
```

**Install on Windows:**  
Use [MSYS2](https://www.msys2.org/) or [WSL](https://learn.microsoft.com/en-us/windows/wsl/).

### Build & Run

```bash
git clone https://github.com/yourusername/student-grade-tracker.git
cd student-grade-tracker
make
./grade_tracker
```

---

## 🖥️ Usage

```
========================================
      STUDENT GRADE TRACKER v1.0
========================================

--- MAIN MENU ---
1. Add Student
2. Add Subject
3. Enter Marks
4. View All Students
5. View Student Report
6. Export HTML Report Card
7. Delete Student
0. Exit
```

### Example Workflow

1. **Add subjects**: Mathematics (100), Science (100), English (100)
2. **Add a student**: John Doe, Roll: 101, Class: 10-A
3. **Enter marks**: Math: 85, Science: 92, English: 78
4. **View report** in terminal or export as HTML

---

## 📊 Grade Scale

| Grade | Percentage |
|-------|------------|
| A+    | ≥ 90%      |
| A     | ≥ 80%      |
| B     | ≥ 70%      |
| C     | ≥ 60%      |
| D     | ≥ 50%      |
| F     | < 50%      |

A student **FAILS** if they score below 35% in any single subject or overall.

---

## 📄 HTML Report Card

After exporting, open the `.html` file in any browser.  
The report card is styled with CSS and includes:
- Student info panel
- Subject-wise marks with progress bars
- Colour-coded grade badges
- Summary cards (overall %, grade, subjects)
- Print-friendly layout

---

## 🤝 Contributing

Pull requests are welcome! To contribute:
1. Fork the repository
2. Create a new branch: `git checkout -b feature/your-feature`
3. Commit your changes: `git commit -m "Add your feature"`
4. Push: `git push origin feature/your-feature`
5. Open a Pull Request

---

## 📝 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

---

## 👤 Author

**Your Name**  
GitHub: [@yourusername](https://github.com/yourusername)
