#ifndef DATABASE_H
#define DATABASE_H

#include <string>
using namespace std;

// Database lifecycle
bool db_init();
void db_close();

// Students
bool db_add_student(const string& name, const string& roll, const string& cls);
bool db_delete_student(int student_id);
void db_list_students();

// Subjects
bool db_add_subject(const string& name, int max_marks);
void db_list_subjects();

// Marks
bool db_enter_marks(int student_id, int subject_id, int marks);

// Reports
void db_print_student_report(int student_id);

// Data structures for report export
struct SubjectMark {
    string subject_name;
    int marks_obtained;
    int max_marks;
    double percentage;
    string grade;
};

struct StudentData {
    int id;
    string name;
    string roll_number;
    string cls;
    SubjectMark subjects[20];
    int subject_count;
    double overall_percentage;
    string overall_grade;
    string status; // Pass / Fail
};

bool db_get_student_data(int student_id, StudentData& data);

#endif
